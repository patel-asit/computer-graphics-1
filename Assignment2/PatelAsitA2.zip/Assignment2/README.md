Author: ASIT PATEL (7866182)

## RUNNING INSTRUCTIONS

There are 3 drawing modes
1. FLAT
2. PHONG_LIGHTING
3. REFLECTIONS_SHADOWS

To switch between the modes, press 's' to go to the next mode and 'w' to go to the previous mode.

Shapes are drawn in the drawShapes() function in Assignment2.pde. They are hardcoded but their constructors can be modified to take in different parameters.